﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minggu6
{
    class Mahasiswa
    {
        private String nama;
        private String nrp;
        private String jurusan;

        public string Nama { get => nama; set => nama = value; }
        public string Nrp { get => nrp; set => nrp = value; }
        public string Jurusan { get => jurusan; set => jurusan = value; }

        public Mahasiswa(string nama, string nrp, string jurusan)
        {
            this.nama = nama;
            this.nrp = nrp;
            this.jurusan = jurusan;
        }
    }
}
