﻿namespace Minggu6
{


    partial class DataSet1
    {
        partial class MahasiswaDataTable
        {
        }

        partial class MahasiswaDataTable
        {
        }
    }
}
