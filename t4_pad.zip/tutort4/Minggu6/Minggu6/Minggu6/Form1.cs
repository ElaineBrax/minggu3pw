﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minggu6
{
    public partial class Form1 : Form
    {
        DataTable dtMahasiswa;
        //variabel global untuk menampung index row datagridview keberapa
        int index = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //inisialisasi tabel baru
            dtMahasiswa = new DataTable("Mahasiswa");
            //menentukanan ada table apasaja
            dtMahasiswa.Columns.Add("Nama");
            dtMahasiswa.Columns.Add("NRP");
            dtMahasiswa.Columns.Add("Jurusan");
            dtMahasiswa.Columns.Add("Action");


            //mengisi data satu persatu 
            DataRow dr = dtMahasiswa.NewRow();
            dr["Nama"] = "Papan";
            dr["NRP"] = "14042";
            dr["Jurusan"] = "S1-Informatika";
            dr["Action"] = "Delete";

            dtMahasiswa.Rows.Add(dr);

            dataGridView1.DataSource = dtMahasiswa;
        }


        //untuk menambahkan data baru ke dalam datagridview
        private void button1_Click(object sender, EventArgs e)
        {
            String nama = textBox1.Text;
            String nrp = textBox2.Text;
            String jurusan = comboBox1.SelectedItem.ToString();

            DataRow dr = dtMahasiswa.NewRow();
            dr["Nama"] = nama;
            dr["NRP"] = nrp;
            dr["Jurusan"] = jurusan;
            dr["Action"] = "Delete";

            dtMahasiswa.Rows.Add(dr);

        }

        //button untuk mengclear teksbox, dan seleksi data sekarang
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.SelectedIndex = 0;
            index = -1;
        }


        //mengubah isi textbox dengan data yang di click
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataRow dr = dtMahasiswa.Rows[e.RowIndex];

            textBox1.Text = dr["Nama"].ToString();
            textBox2.Text = dr["NRP"].ToString();
            comboBox1.SelectedItem = dr["Jurusan"].ToString();

            index = e.RowIndex;
        }

        //delete data (row) ketika dipencet

        private void button2_Click(object sender, EventArgs e)
        {
            if(index != -1)
            {
                dtMahasiswa.Rows.RemoveAt(index);
            }
            else
            {
                MessageBox.Show("Tidak ada row di pilih");
            }

        }

        //untuk mengupdate data ditempat yang dipilih
        private void button4_Click(object sender, EventArgs e)
        {
            String nama = textBox1.Text;
            String nrp = textBox2.Text;
            String jurusan = comboBox1.SelectedItem.ToString();

            DataRow dr = dtMahasiswa.Rows[index];
            dr["Nama"] = nama;
            dr["NRP"] = nrp;
            dr["Jurusan"] = jurusan;    
        }

        //untuk mengatur formatting di dalam tabel datagrid
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //digunakan untuk mengatur bagian kolom 1 (NRP) saja
            if(e.ColumnIndex == 1)
            {
                int nrp = Int32.Parse(e.Value.ToString());


                //apabila nilai nrp genap maka warnanya akan menjadi cyan
                if(nrp % 2 == 0)
                {
                    e.CellStyle.BackColor = Color.Cyan;

                }
                //apabila nilai nrp ganjil maka warnanya akan menjadi limegreen
                else
                {
                    e.CellStyle.BackColor = Color.LimeGreen;
                }
                //mengatur alignment menjadi center
                e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            //digunakan untuk mengatur bagian kolom 0 (Nama) saja
            if(e.ColumnIndex == 0)
            {
                String nama = e.Value.ToString();

                //apabila nama lebih panjang daripada 8 maka selebihnya akan diganti oleh . . .
                if(nama.Length > 8)
                {
                    nama = nama.Substring(0, 8) + "...";
                }
                e.Value = nama;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //membuat aksi pada tombol delete untuk mendelete row ketika ditekan
            if(e.ColumnIndex == 3)
            {
                dtMahasiswa.Rows.RemoveAt(e.RowIndex);
            }
        }

        //digunakan untuk menemukan row sesuai dengan yang dicari
        private void btSearch_Click(object sender, EventArgs e)
        {
            String temp = tbSearch.Text.ToString();

            //mencari berdasarkan row yang mana
            DataRow[] dr = dtMahasiswa.Select("NRP like '%"+temp +"%'");
            foreach (DataRow d in dr)
            {
                //menampilkan data cell keberapa
                Console.WriteLine(d[0]);
            }
        }
    }
}
