﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minggu6
{
    public partial class Form3 : Form
    {
        //cara ke 3 menggunakan dataset
        //inisialisasikan dataset terlebih dahulu jadi variabel global
        //jangan lupa buat dataset melalui klik kanan di solution explorer -> add(ctrl + shift + a)
        //-> dataset -> klik kanan -> add -> datatable -> klik kanan pada tabel-> add -> column
        //
        DataSet1 ds = new DataSet1();
        public Form3()
        {
            InitializeComponent();
            //menambahkan data ke dalam datagridview secara dataset
            DataRow dr = ds.Tables["Mahasiswa"].NewRow();
            dr["Nama"] = "Papan";
            dr["Nrp"] = "2201168322";
            dr["Jurusan"] = "S1-Informatika";
            ds.Tables["Mahasiswa"].Rows.Add(dr);
            dataGridView1.DataSource = ds.Tables["Mahasiswa"];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String nama = textBox1.Text;
            String nrp = textBox2.Text;
            String jurusan = comboBox1.SelectedItem.ToString();

            //melakukan insert data ke dalam datagridview secara dataset
            DataRow dr = ds.Tables["Mahasiswa"].NewRow();
            dr["Nama"] = nama;
            dr["Nrp"] = nrp;
            dr["Jurusan"] = jurusan;
            ds.Tables["Mahasiswa"].Rows.Add(dr);
        }
    }
}
